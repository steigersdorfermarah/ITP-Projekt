public class Vocabulary {

    String germanWord = "";
    String englishWord = "";

    public Vocabulary(String germanWord, String englishWord) {
        this.germanWord = germanWord;
        this.englishWord = englishWord;
    }

    public String getGermanWord() {
        return germanWord;
    }

    public String getEnglishWord() {
        return englishWord;
    }

    @Override
    public String toString() {
        return "Vocabulary{" +
                "germanWord='" + germanWord + '\'' +
                ", englishWord='" + englishWord + '\'' +
                '}';
    }
}
