import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    static Scanner scanner = new Scanner(System.in);
    static List<Vocabulary> vocabularyList = new ArrayList<Vocabulary>();
    static List<String> englishWordList = new ArrayList<>();
    
    public static void main(String[] args) {
        int amount = 0;
        String input = "";
        String input2 = "";
        String inputEnglishWord = "";


        do {
            System.out.print("How many vocabularies do you want to learn? ");
            amount = scanner.nextInt();

            addWords(amount);
            System.out.print("Do you want to add some more vocabularies?<y/n> ");
            input = scanner.next();

        }while (input.equalsIgnoreCase("y"));

        if (input.equalsIgnoreCase("n")){
            System.out.print("Do you want to check the words? <y/n> ");
            input2 = scanner.next();
            if (input2.equalsIgnoreCase("y")){
                for (int i = 0; i < vocabularyList.size(); i++) {
                    System.out.print(vocabularyList.get(i).getGermanWord() + "=");
                    inputEnglishWord = scanner.next();
                    englishWordList.add(inputEnglishWord);
                }
                int points = checkWords();
                System.out.println("");
                System.out.println("You have "+ points+" out of "+ vocabularyList.size() + " points!");

            }else {
                System.out.println("");
                System.out.println("Goodbye");
            }
        }
    }

    private static int checkWords() {
        int counter = 0;

        for (int i = 0; i < vocabularyList.size(); i++) {
            if (vocabularyList.get(i).getEnglishWord().equals(englishWordList.get(i))){
                counter++;
            }
        }
        return counter;
    }

    private static List<Vocabulary> addWords(int amount) {
        String germanWord = "";
        String englishWord = "";

        for (int i = 0; i < amount; i++) {
            System.out.print("German word: ");
            germanWord = scanner.next();
            System.out.print("English Word: ");
            englishWord = scanner.next();
            System.out.println("");

            Vocabulary vocabulary = new Vocabulary(germanWord, englishWord);
            vocabularyList.add(vocabulary);
        }
        return vocabularyList;
    }
}
